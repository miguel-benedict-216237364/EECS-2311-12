package application;

import javafx.collections.ObservableList;
import javafx.scene.control.TextField;

public class Model {
	
	static TextField textField;

	static void setDefault(ObservableList<TextField> observableList) {
		
		


	}

}
